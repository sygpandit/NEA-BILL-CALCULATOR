Just a web app that shows the amount required according to the energy consumption as per rules set by Nepal Electricity Authority.
![neab](https://user-images.githubusercontent.com/71134352/130031070-f7ad9c49-1a46-475d-9154-143c3bc95e83.png)
